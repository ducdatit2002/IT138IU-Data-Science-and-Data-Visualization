change the code from histogramNoneD3.js to D3 framwork
